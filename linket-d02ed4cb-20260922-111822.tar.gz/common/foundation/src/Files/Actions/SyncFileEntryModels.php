<?php

namespace Common\Files\Actions;

use Common\Files\FileEntry;
use Common\Files\Uploads\Uploads;
use Illuminate\Database\Eloquent\Relations\MorphToMany;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\DomCrawler\Crawler;

class SyncFileEntryModels
{
    public function fromHtml(string|null $html, MorphToMany $relation)
    {
        $fileNames = $this->getFileNamesFromImagesInHtml($html);

        $entries = !empty($fileNames)
            ? FileEntry::whereIn('file_name', $fileNames)->get()
            : [];

        $relation->sync($entries);
    }

    public function fromUrl(string|null $url, MorphToMany $relation): ?FileEntry
    {
        if (!$url || !$this->isUrlForUploadedFile($url)) {
            return null;
        }

        $entry = FileEntry::where(
            'file_name',
            $this->fileNameFromUrl($url),
        )->first();

        if ($entry) {
            $relation->sync($entry);
        }

        return $entry;
    }

    public function fromArray(array $array, MorphToMany $relation)
    {
        $fileNames = $this->extractFileNamesFromArray($array);

        if (!empty($fileNames)) {
            $entries = FileEntry::whereIn('file_name', $fileNames)->get();
            $relation->sync($entries);
        }
    }

    public function fromEntryIds(array $entryIds, MorphToMany $relation)
    {
        $relation->sync($entryIds);
    }

    public function entryFileNameFromUrl(string $url): ?string
    {
        if ($this->isUrlForUploadedFile($url)) {
            return $this->fileNameFromUrl($url);
        }

        return null;
    }

    public function entryFileNameFromString($string): ?string
    {
        if (!is_string($string) || strlen($string) < 4) {
            return null;
        }

        // background image selector support
        if (Str::contains($string, 'url(')) {
            $string = preg_match('/url\((.*?)\)/', $string, $matches)
                ? $matches[1]
                : null;
        }

        if ($this->isStringAnUrlForUploadedImage($string)) {
            return $this->fileNameFromUrl($string);
        }

        return null;
    }

    public function extractFileNamesFromArray(
        array $array,
        array &$fileNames = [],
    ) {
        foreach ($array as $value) {
            if (is_array($value)) {
                $this->extractFileNamesFromArray($value, $fileNames);
            } else {
                if ($filename = $this->entryFileNameFromString($value)) {
                    $fileNames[] = $filename;
                }
            }
        }

        return $fileNames;
    }

    public function getFileNamesFromImagesInHtml(string|null $html): array
    {
        if (!$html) {
            return [];
        }

        $fileNames = [];
        $crawler = new Crawler();
        $crawler->addHtmlContent($html, 'UTF-8');

        $crawler
            ->filter('img[src]')
            ->each(function (Crawler $img) use (&$fileNames) {
                $url = $img->attr('src');
                if ($this->isUrlForUploadedFile($url)) {
                    $fileNames[] = $this->fileNameFromUrl($url);
                }
            });

        return $fileNames;
    }

    protected function fileNameFromUrl(string $url): string
    {
        return basename(parse_url($url)['path']);
    }

    public function isStringAnUrlForUploadedImage(string $url): bool
    {
        $path = parse_url($url, PHP_URL_PATH);
        $pathInfo = pathinfo($path);
        $dir = Arr::get($pathInfo, 'dirname');
        $extension = Arr::get($pathInfo, 'extension');
        $filename = Arr::get($pathInfo, 'filename');

        if ($dir && $dir !== '.' && $extension && $filename) {
            return $this->isUrlForUploadedFile($url);
        }

        return false;
    }

    public function isUrlForUploadedFile(string|null $url = null)
    {
        if (!$url) {
            return false;
        }

        // does not seem to be a url (relative or otherwise)
        if (!Str::contains($url, '/')) {
            return false;
        }

        // is relative
        if (Str::startsWith($url, '/') || !Str::startsWith($url, 'http')) {
            return true;
        }

        // is using app domain
        if (Str::startsWith($url, config('app.url'))) {
            return true;
        }

        foreach (Uploads::getAllBackends() as $backend) {
            // is using configured CDN
            if (
                $backend->customDomain &&
                Str::startsWith($url, $backend->customDomain)
            ) {
                return true;
            }

            // is using default url from remote store (eg. https://bucket.s3.eu-north-1.amazonaws.com)
            if (!$backend->isLocal()) {
                $remoteUrl = Storage::build([
                    'driver' => $backend->flysystemDriver(),
                    'root' => '',
                    ...$backend->config,
                ])->url('empty.txt');
                $remoteUrl = str_replace('empty.txt', '', $remoteUrl);
                if ($remoteUrl && Str::startsWith($url, $remoteUrl)) {
                    return true;
                }
            }
        }

        return false;
    }
}
