<?php

namespace Common\Auth\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Ban extends Model
{
    protected $guarded = [];

    protected $casts = [
        'expired_at' => 'datetime',
    ];

    const MODEL_TYPE = 'ban';

    public static function getModelTypeAttribute(): string
    {
        return self::MODEL_TYPE;
    }

    protected static function booted(): void
    {
        static::created(function (Ban $ban) {});
    }

    public function createdBy(): MorphTo
    {
        return $this->morphTo('created_by');
    }

    public function bannable(): MorphTo
    {
        return $this->morphTo();
    }
}
